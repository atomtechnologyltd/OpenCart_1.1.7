<?php
// Text
$_['text_title']       = 'Credit Card / Debit Card / Net-Banking (Atom Bank Payment)';
$_['text_description'] = 'Items on %s Order No: %s';
?>